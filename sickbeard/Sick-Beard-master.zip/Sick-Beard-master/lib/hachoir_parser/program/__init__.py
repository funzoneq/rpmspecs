from lib.hachoir_parser.program.elf import ElfFile
from lib.hachoir_parser.program.exe import ExeFile
from lib.hachoir_parser.program.python import PythonCompiledFile
from lib.hachoir_parser.program.java import JavaCompiledClassFile
from lib.hachoir_parser.program.prc import PRCFile

