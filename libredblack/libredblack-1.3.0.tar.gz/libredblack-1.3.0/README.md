# libredblack
Copy of RedBlack Balanced Tree Searching and Sorting Library - http://libredblack.sourceforge.net/
