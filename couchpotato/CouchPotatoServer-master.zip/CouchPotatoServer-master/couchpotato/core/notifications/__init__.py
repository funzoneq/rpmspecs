config = {
    'name': 'notification_providers',
    'groups': [
        {
            'label': 'Notifications',
            'description': 'Notify when movies are done or snatched',
            'type': 'list',
            'name': 'notification_providers',
            'tab': 'notifications',
            'options': [],
        },
    ],
}
