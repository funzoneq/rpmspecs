from .main import OMDBAPI

def start():
    return OMDBAPI()

config = []
