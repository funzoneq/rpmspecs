from .main import RottenTomatoes

def start():
    return RottenTomatoes()

config = []
