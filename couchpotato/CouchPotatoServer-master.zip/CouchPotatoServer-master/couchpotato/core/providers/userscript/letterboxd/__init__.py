from .main import Letterboxd

def start():
    return Letterboxd()

config = []
