from .main import Filmweb

def start():
    return Filmweb()

config = []
