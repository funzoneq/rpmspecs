from .main import YouTheater

def start():
    return YouTheater()

config = []
