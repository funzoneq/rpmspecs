from .main import IMDB

def start():
    return IMDB()

config = []
