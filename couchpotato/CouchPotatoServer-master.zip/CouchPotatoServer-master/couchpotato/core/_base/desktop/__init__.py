from .main import Desktop

def start():
    return Desktop()

config = []
