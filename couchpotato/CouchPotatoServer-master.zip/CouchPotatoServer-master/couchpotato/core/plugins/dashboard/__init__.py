from .main import Dashboard

def start():
    return Dashboard()

config = []
