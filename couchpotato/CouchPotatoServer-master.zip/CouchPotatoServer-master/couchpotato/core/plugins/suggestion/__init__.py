from .main import Suggestion

def start():
    return Suggestion()

config = []
