from .main import StatusPlugin

def start():
    return StatusPlugin()

config = []
